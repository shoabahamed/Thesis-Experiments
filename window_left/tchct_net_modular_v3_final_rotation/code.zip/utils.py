"""
Utility functions: class weights, WER computation, model save/load, plotting.

Provides:
  - compute_class_weights : inverse-frequency class weighting
  - compute_wer           : word error rate via edit distance
  - remove_consecutive_duplicates / remove_background : label cleaning
  - save_unique_model     : save model checkpoint with metadata
  - plot_training_curves  : matplotlib loss/accuracy plots
"""
from __future__ import annotations

import json
import os
import subprocess
import sys
import uuid
from collections import Counter
from datetime import datetime, timezone
from pathlib import Path

import matplotlib.pyplot as plt
import numpy as np
import torch
import torch.nn as nn
from sklearn.metrics import confusion_matrix

from config import (
    BACKGROUND_LABEL,
    DEVICE,
    MODEL_NAME,
    NORMALIZATION_NAME,
    PROJECT_ROOT,
)


# ──────────────────────────────────────────────────────────────────────
# Class weights
# ──────────────────────────────────────────────────────────────────────

def compute_class_weights(
    train_dataset,
    num_classes: int,
) -> torch.Tensor:
    """Compute inverse-frequency class weights from training dataset.

    Returns a (num_classes,) tensor on DEVICE.
    """
    frame_counts = Counter()
    if hasattr(train_dataset, "y"):
        frame_counts.update(train_dataset.y.tolist())
    else:
        for sample in train_dataset.samples:
            frame_counts.update(sample["labels"].tolist())


    epsilon = 1e-6
    raw_weights = np.array(
        [1.0 / (frame_counts.get(c, 0) + epsilon) for c in range(num_classes)],
        dtype=np.float32,
    )
    class_weights = raw_weights * (num_classes / raw_weights.sum())
    return torch.tensor(class_weights, dtype=torch.float32, device=DEVICE)


class FocalLoss(nn.Module):
    """Focal Loss for multi-class classification.

    FL(p_t) = -alpha_t * (1 - p_t)^gamma * log(p_t)

    Supports per-class weights (alpha) and ignore_index for padding.
    """

    def __init__(
        self,
        weight: torch.Tensor | None = None,
        gamma: float = 2.0,
        ignore_index: int = -1,
        reduction: str = "mean",
    ):
        super().__init__()
        self.gamma = gamma
        self.ignore_index = ignore_index
        self.reduction = reduction
        if weight is not None:
            self.register_buffer("weight", weight)
        else:
            self.weight = None

    def forward(self, input: torch.Tensor, target: torch.Tensor) -> torch.Tensor:
        mask = target != self.ignore_index
        if not mask.any():
            return torch.tensor(0.0, device=input.device, requires_grad=True)

        input_m = input[mask]
        target_m = target[mask]

        log_p = torch.nn.functional.log_softmax(input_m, dim=-1)
        p = torch.exp(log_p)

        log_p_true = log_p.gather(1, target_m.unsqueeze(1)).squeeze(1)
        p_true = p.gather(1, target_m.unsqueeze(1)).squeeze(1)

        focal_weight = (1.0 - p_true) ** self.gamma
        loss = -focal_weight * log_p_true

        if self.weight is not None:
            alpha = self.weight[target_m]
            loss = loss * alpha

        if self.reduction == "mean":
            return loss.mean()
        elif self.reduction == "sum":
            return loss.sum()
        return loss


# ──────────────────────────────────────────────────────────────────────
# WER helpers
# ──────────────────────────────────────────────────────────────────────

def remove_consecutive_duplicates(labels: list[str]) -> list[str]:
    """Collapse consecutive duplicate labels while preserving order."""
    if not labels:
        return []
    out = [labels[0]]
    for lbl in labels[1:]:
        if lbl != out[-1]:
            out.append(lbl)
    return out


def remove_background(
    labels: list[str],
    background_label: str = BACKGROUND_LABEL,
) -> list[str]:
    """Remove background labels from a label sequence."""
    return [lbl for lbl in labels if lbl != background_label]


def compute_wer(pred: list[str], gt: list[str]) -> float:
    """Compute Word Error Rate using Levenshtein edit distance."""
    n, m = len(gt), len(pred)
    if n == 0:
        return 0.0 if m == 0 else 1.0

    dp = np.zeros((n + 1, m + 1), dtype=np.int32)
    for i in range(1, n + 1):
        dp[i, 0] = i
    for j in range(1, m + 1):
        dp[0, j] = j
    for i in range(1, n + 1):
        for j in range(1, m + 1):
            cost     = 0 if gt[i - 1] == pred[j - 1] else 1
            dp[i, j] = min(
                dp[i-1, j] + 1, dp[i, j-1] + 1, dp[i-1, j-1] + cost,
            )

    return float(dp[n, m] / n)


# ──────────────────────────────────────────────────────────────────────
# Model save / load
# ──────────────────────────────────────────────────────────────────────

def save_unique_model(
    model_obj: nn.Module,
    best_val_acc: float | None = None,
    save_dir: str = "trained_models",
    model_name: str = MODEL_NAME,
    info: dict | None = None,
) -> str:
    """Save model checkpoint with unique filename and metadata JSON."""
    os.makedirs(save_dir, exist_ok=True)
    ts = datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%SZ")
    short_id = uuid.uuid4().hex[:8]

    val_str = f"{best_val_acc:.4f}" if best_val_acc is not None else "nan"
    filename = f"{ts}_{model_name}_val-{val_str}_{short_id}.pt"
    path = os.path.join(save_dir, filename)

    metadata = {
        "model_name": model_name,
        "saved_at_utc": ts,
        "uid": short_id,
        "best_val_acc": best_val_acc,
        "normalization": NORMALIZATION_NAME,
    }

    try:
        git_sha = subprocess.check_output(
            ["git", "rev-parse", "--short", "HEAD"],
            cwd=str(PROJECT_ROOT),
            stderr=subprocess.DEVNULL,
        ).decode().strip()
        metadata["git_sha"] = git_sha
    except Exception:
        pass

    if info:
        metadata.update(info)

    payload = {"model_state_dict": model_obj.state_dict(), "metadata": metadata}
    torch.save(payload, path)

    try:
        with open(path + ".json", "w", encoding="utf-8") as f:
            json.dump(metadata, f, indent=2)
    except Exception:
        pass

    print(f"Saved model checkpoint: {path}")
    return path


def load_model_checkpoint(
    checkpoint_path: str,
    map_location: str | torch.device | None = DEVICE,
) -> tuple[dict, dict]:
    """Load a saved checkpoint payload and its metadata.

    Returns
    -------
    model_state_dict : dict
    metadata         : dict
    """
    payload = torch.load(checkpoint_path, map_location=map_location)
    if isinstance(payload, dict) and "model_state_dict" in payload:
        model_state_dict = payload["model_state_dict"]
        metadata = payload.get("metadata", {})
    else:
        model_state_dict = payload
        metadata = {}
    return model_state_dict, metadata


# ──────────────────────────────────────────────────────────────────────
# Plotting
# ──────────────────────────────────────────────────────────────────────

def plot_training_curves(train_result: dict, save_path: str | None = None) -> None:
    """Plot loss, accuracy, and macro-F1 curves — one image per metric.

    With ``save_path='.../curves_test_user3.png'``, three files are written:
    ``curves_test_user3_loss.png``, ``curves_test_user3_accuracy.png`` and
    ``curves_test_user3_f1.png``.
    """
    history_train_loss = train_result["history_train_loss"]
    history_train_batch_acc = train_result["history_train_batch_acc"]
    history_val_loss = train_result.get("history_val_loss", [])
    history_val_acc = train_result["history_val_acc"]
    history_train_f1 = train_result.get("history_train_f1", [])
    history_val_f1 = train_result.get("history_val_f1", [])

    epochs_axis = np.arange(1, len(history_train_loss) + 1)

    def _finish(metric_slug: str) -> None:
        plt.tight_layout()
        if save_path:
            root, ext = os.path.splitext(save_path)
            metric_path = f"{root}_{metric_slug}{ext or '.png'}"
            plt.savefig(metric_path, dpi=150, bbox_inches="tight")
            print(f"Training curve saved to: {metric_path}")
        else:
            plt.show()
        plt.close()

    # ── Loss ──
    plt.figure(figsize=(6, 4.5))
    plt.plot(epochs_axis, history_train_loss, marker="o", label="Train")
    if len(history_val_loss) == len(epochs_axis):
        plt.plot(
            epochs_axis, history_val_loss,
            marker="s", linestyle="--", label="Validation",
        )
    plt.title("Loss")
    plt.xlabel("Epoch")
    plt.ylabel("Loss")
    plt.legend()
    plt.grid(True, alpha=0.3)
    _finish("loss")

    # ── Accuracy ──
    plt.figure(figsize=(6, 4.5))
    if len(history_train_batch_acc) == len(epochs_axis):
        plt.plot(
            epochs_axis, history_train_batch_acc,
            marker="x", linestyle="--", label="Train (batch)",
        )
    plt.plot(epochs_axis, history_val_acc, marker="o", label="Validation")
    plt.title("Accuracy")
    plt.xlabel("Epoch")
    plt.ylabel("Accuracy")
    plt.legend()
    plt.grid(True, alpha=0.3)
    _finish("accuracy")

    # ── Macro F1 ──
    plt.figure(figsize=(6, 4.5))
    if len(history_train_f1) == len(epochs_axis):
        plt.plot(
            epochs_axis, history_train_f1,
            marker="x", linestyle="--", label="Train (batch)",
        )
    if len(history_val_f1) == len(epochs_axis):
        plt.plot(epochs_axis, history_val_f1, marker="o", label="Validation")
    plt.title("Macro F1")
    plt.xlabel("Epoch")
    plt.ylabel("F1")
    plt.legend()
    plt.grid(True, alpha=0.3)
    _finish("f1")


def save_confusion_matrix_plots(
    y_true,
    y_pred,
    class_names: list[str],
    save_dir: str,
    split_name: str,
) -> dict[str, str]:
    """Save normalized and misclassification confusion matrix plots.

    The normalized plot uses row-wise percentages to remain readable when
    class frequencies are highly imbalanced. The misclassification plot
    zeros the diagonal and highlights off-diagonal errors with a log color scale.
    """
    os.makedirs(save_dir, exist_ok=True)

    labels = list(range(len(class_names)))
    cm = confusion_matrix(y_true, y_pred, labels=labels)
    cm = np.asarray(cm, dtype=np.int64)

    row_totals = cm.sum(axis=1, keepdims=True)
    cm_norm = np.divide(
        cm.astype(np.float32),
        row_totals,
        out=np.zeros_like(cm, dtype=np.float32),
        where=row_totals != 0,
    )

    def _draw_matrix(matrix: np.ndarray, title: str, cmap: str, annotate_mode: str, filename: str):
        size = max(8.0, 0.45 * len(class_names))
        fig, ax = plt.subplots(figsize=(size, size))
        image = ax.imshow(matrix, interpolation="nearest", cmap=cmap, aspect="auto")
        ax.set_title(title)
        ax.set_xlabel("Predicted label")
        ax.set_ylabel("True label")
        ax.set_xticks(np.arange(len(class_names)))
        ax.set_yticks(np.arange(len(class_names)))
        ax.set_xticklabels(class_names, rotation=45, ha="right")
        ax.set_yticklabels(class_names)

        if annotate_mode == "normalized":
            threshold = 0.5
            for i in range(matrix.shape[0]):
                for j in range(matrix.shape[1]):
                    pct = matrix[i, j]
                    count = cm[i, j]
                    if count == 0:
                        continue
                    color = "white" if pct > threshold else "black"
                    ax.text(
                        j, i,
                        str(count),
                        ha="center", va="center",
                        color=color, fontsize=8,
                    )
            fig.colorbar(image, ax=ax, fraction=0.046, pad=0.04, label="Row-normalized rate")
        elif annotate_mode == "errors":
            for i in range(matrix.shape[0]):
                for j in range(matrix.shape[1]):
                    if i == j:
                        continue
                    count = int(cm[i, j])
                    if count == 0:
                        continue
                    color = "white" if matrix[i, j] > 0.75 else "black"
                    ax.text(
                        j, i,
                        str(count),
                        ha="center", va="center",
                        color=color, fontsize=8,
                    )
            fig.colorbar(image, ax=ax, fraction=0.046, pad=0.04, label="log1p(misclassification count)")

        fig.tight_layout()
        path = os.path.join(save_dir, filename)
        fig.savefig(path, dpi=180, bbox_inches="tight")
        plt.close(fig)
        return path

    normalized_path = _draw_matrix(
        cm_norm,
        title=f"{split_name} Confusion Matrix (row-normalized)",
        cmap="Blues",
        annotate_mode="normalized",
        filename=f"{split_name}_confusion_normalized.png",
    )

    cm_errors = cm.copy().astype(np.float32)
    np.fill_diagonal(cm_errors, 0.0)
    cm_errors_log = np.log1p(cm_errors)
    errors_path = _draw_matrix(
        cm_errors_log,
        title=f"{split_name} Misclassification Counts (off-diagonal)",
        cmap="magma",
        annotate_mode="errors",
        filename=f"{split_name}_confusion_misclassifications.png",
    )

    print(f"Confusion matrix saved to: {normalized_path}")
    print(f"Misclassification matrix saved to: {errors_path}")

    return {"normalized": normalized_path, "misclassifications": errors_path}


# ──────────────────────────────────────────────────────────────────────
# Console Logging redirection (Tee)
# ──────────────────────────────────────────────────────────────────────

class TeeLogger:
    """Redirects sys.stdout and sys.stderr to both a file and standard output."""

    def __init__(self, filepath: str):
        log_dir = os.path.dirname(filepath)
        if log_dir:
            os.makedirs(log_dir, exist_ok=True)
        self.file = open(filepath, "w", encoding="utf-8")
        self.stdout = sys.stdout
        self.stderr = sys.stderr
        sys.stdout = self
        sys.stderr = self

    def write(self, data):
        self.stdout.write(data)
        # Skip writing tqdm progress bars (which use \r) to the log file
        if "\r" in data:
            return
        self.file.write(data)
        self.file.flush()

    def flush(self):
        self.stdout.flush()
        self.file.flush()

    def __getattr__(self, attr):
        return getattr(self.stdout, attr)

    def close(self):
        if sys.stdout is self:
            sys.stdout = self.stdout
        if sys.stderr is self:
            sys.stderr = self.stderr
        self.file.close()

